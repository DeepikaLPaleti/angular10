import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //where to inject

  template: '<i> <h1> {{title}} </h1>  </i>', //where to display
  templateUrl: './app.component.html', //where to display


  styleUrls: ['./app.component.css'] //how to display
})
export class AppComponent {
  title = 'Angular 10 at Sai Tec'; //what to display
}
