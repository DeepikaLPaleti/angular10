import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { Ng2SearchPipeModule } from 'ng2-search-filter';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { HomeComponent } from './home/home.component';
import { GenderPipe } from './gender.pipe';
import { Gender1Pipe } from './gender1.pipe';
import { OrderByPipe } from './order-by.pipe';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { CommentsComponent } from './comments/comments.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import {PostsService} from "./services/posts.service";
@NgModule({
  declarations: [ //components,dicrectives,pipes
    AppComponent, AngularBasicsComponent, TechnologiesComponent, AngularPipesComponent, 
    HomeComponent, GenderPipe, Gender1Pipe, OrderByPipe, CaseStudyComponent, UsersComponent, PostsComponent, CommentsComponent, TodosComponent, AlbumsComponent, PhotosComponent, UsersListComponent, UsersTableComponent
  ],
  imports: [ //modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    Ng2SearchPipeModule,
    HttpClientModule
  ],
  providers: [PostsService],//services before angular 5
 // bootstrap: [AppComponent,AngularBasicsComponent,AngularPipesComponent,TechnologiesComponent] //components
 bootstrap: [AppComponent] //components

})
export class AppModule { }
