import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css']
})
export class StateComponent implements OnInit {

  name="Maharashtra";

  @Input()
  countryName="";

  cityName="";

  @Output()
  cityChanged=new EventEmitter<string>();
  
  @Output()
  stateChanged=new EventEmitter<string>();
  


  sendCity(name){
   this.cityName=name;
   this.cityChanged.emit(this.cityName);
  }


  sendState(){
   this.stateChanged.emit(this.name);
  }
  
  constructor() { }

  ngOnInit(): void {
  }

}
