import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender1'
})
export class Gender1Pipe  {

  transform(value :number,isMarried:boolean): string {
      
    console.log(value+"    "+isMarried)

    if(value==1){
        return "Mr.";
    }
    else if(value==2)
    {
      if(isMarried)
      return "Mrs.";
      else 
       return "Miss.";
    }
    
    return "";
  }

}
