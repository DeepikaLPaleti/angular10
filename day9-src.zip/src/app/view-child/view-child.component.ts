import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { NumberComponent } from '../number/number.component';
import { FgColorDirective } from '../directives/fg-color.directive';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {

@ViewChild(NumberComponent,{static:false})
n:NumberComponent;


@ViewChild(FgColorDirective,{static:false})
f:FgColorDirective;

@ViewChild("name",{static:false})
name:ElementRef<any>;

@ViewChild("city",{static:false})
city:ElementRef<any>;

@ViewChild("x",{static:false})
x:ElementRef<any>;
constructor() { }

  ngOnInit(): void {
  }

  increase(){
   this.n.increment();
  }

  decrease(){   
  this.n.decrement();
  }

changeColor(){
  this.f.fgColor="green";
}


changeColors(){
  this.name.nativeElement.style.color="RED";
  this.city.nativeElement.style.color="GREEN"; 
  this.x.nativeElement.style.color="GREEN";
        
  this.name.nativeElement.style.backgroundColor="CYAN";
  this.x.nativeElement.style.backgroundColor="PINK";
  this.city.nativeElement.style.backgroundColor="YELLOW";
}

}
