import { Component, OnInit } from '@angular/core';
import { StudentsService } from '../services/students.service';
import { PagerService } from '../services/pager.service';



@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  title="Express Student CRUD APP";

  students:any;


  student=null;
  

     // pager object
   pager: any = {};

   // paged items
   pagedItems: any[];
 
 
  message="";

  add=false;
  update=false;

  constructor(private ss:StudentsService) 
  {    console.log("==========StudentComponent created =============");
  }

   ngOnInit(): void {
     this.getAllStudents();  
     console.log("---------------",this.students);
  }

  newStudent(){

    this.add=false;
    this.update=true;
    this.student={
      id:0,
      name:'',
      marks:0.0,
      dob:new Date()
    }
  }
  ngOnDestroy(): void {
    console.log("==========StudentComponent destroyed =============");
    
  }


  getAllStudents(){
    this.ss.getAllStudents().subscribe(response=>
      this.students=response
      
    ,error=>this.message=error);
  }

  getStudentById(studentId:number){
     this.add=true;
     this.update=false;
    this.ss.getStudentById(studentId).subscribe(response=>{this.student=response;
      },error=>this.message=error);
  }

  deleteStudentById(studentId:number){
    this.ss.deleteStudentById(studentId).subscribe(response=>{this.students=response;
      },error=>this.message=error);
  }

  updateStudent(){
    this.ss.updateStudentById(this.student.id,this.student).subscribe(response=>{this.students=response;
      },error=>this.message=error);

      this.student=null;
  }

  addStudent(){
    this.ss.addStudent(this.student).subscribe(response=>{this.students=response;
      },error=>this.message=error);

      this.student=null;
  }







}
