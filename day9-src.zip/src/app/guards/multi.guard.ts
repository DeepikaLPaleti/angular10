import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanDeactivate, CanLoad, Route, UrlSegment, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MultiGuard implements CanActivate, CanActivateChild, CanDeactivate<unknown>, CanLoad {
  


  constructor(private router:Router){

  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
         
      var email=sessionStorage.getItem("email");
      if(email==null ||email ==undefined)
       {
         alert("Login First");
         this.router.navigate(['/login']);
         return false;
        }      
      else
             return true;
      
  }
  
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
    
      var email=sessionStorage.getItem("email");
      if(email!='pradeep@gmail.com')
       {
         alert("You are not authorized person to visist this section,Trye different credientials");
         this.router.navigate(['/login']);
         return false;
        }      
      else
             return true;
      
  }
  
  canDeactivate(
    component: unknown,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return confirm("Do want to leave this page?");

  }
  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
    return confirm("Dou want to load the address module?");
  }

}
