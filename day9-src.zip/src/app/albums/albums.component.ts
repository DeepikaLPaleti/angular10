import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../services/albums.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit {
  title="Albums Table";

  albums:any;
 
  message="";
  
  userId=0;


 
   constructor(private as:AlbumsService,private route:ActivatedRoute) {
     console.log("===========UsersTableComponent created===============");
    }
 
   ngOnInit() {

    this.userId=this.route.snapshot.queryParams.userId;
    console.log("===========UsersTableComponent initialized==============="+this.userId);
     
 
    if(this.userId)
     this.getAllAlbumsByUserId();
     else
     this.getAllAlbums();
     
     
     
   }
  
   ngOnDestroy() {
     console.log("===========UsersTableComponent destroyed===============");
   }
 
 
 
   getAllAlbums(){
   
     this.as.getAllAlbums()
            .subscribe(response=>this.albums=response,
             error=>this.message=error)
 
   }


   getAllAlbumsByUserId(){
   
    this.as.getAllAlbumsByUserId(this.userId)
           .subscribe(response=>this.albums=response,
            error=>this.message=error)

  }

}
