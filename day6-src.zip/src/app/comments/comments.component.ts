import { Component, OnInit } from '@angular/core';
import {CommentsService} from "../services/comments.service";
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  
  title="All Comments";

  comments:any;

  postId=0;
  
  message="";
  constructor(private cs:CommentsService,private route:ActivatedRoute) 
  {    console.log("==========CommentsComponent created =============");
  }

   ngOnInit(): void {

    this.postId=this.route.snapshot.queryParams.postId;
    console.log("==========CommentsComponent initialized ============= "+this.postId);
   
    if(this.postId)
     this.getAllCommentsByPostId();
     else
     this.getAllComments();  
  }

  ngOnDestroy(): void {
    console.log("==========PostsComponent destroyed =============");
    
  }


  getAllComments(){
    this.cs.getAllComments().subscribe(response=>this.comments=response,error=>this.message=error);
  }

  getAllCommentsByPostId(){
    this.cs.getAllCommentsByPostId(this.postId).subscribe(response=>this.comments=response,error=>this.message=error);
  }


}
