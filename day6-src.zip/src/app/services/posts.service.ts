import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class PostsService {

  private baseURL="https://jsonplaceholder.typicode.com/posts";

    constructor(private http:HttpClient) {
           console.log("********* PostsService created *******")
     }

     getAllPosts():Observable<any>{
       console.log("@@@@@@@@@@@@@@@@@@@@@@@@ getAllPosts Called  @@@@@@@@@@@@@@@@@@@@@@@");
      return this.http.get(this.baseURL);
    }
    getPostById(postId:number){
      return this.http.get(this.baseURL+"/"+postId);
    }
    getAllPostsByUserId(userId:number){
      return this.http.get(this.baseURL+"?userId="+userId);
    }
    

}
