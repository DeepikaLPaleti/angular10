var express=require("express");
var cors=require("cors");

students=[
    {id:1,name:'Pradeep',marks:78.500,dob:new Date("July 31,1982")},
    {id:2,name:'Sachin',marks:67.440,dob:new Date("May 31,1988")},
    {id:3,name:'Sunil',marks:56.770,dob:new Date("April 31,1972")},
    {id:4,name:'Mahesh',marks:44.660,dob:new Date("July 31,1999")},
    {id:5,name:'Prasad',marks:88.550,dob:new Date("August 31,1999")},
    ];

var server=express();

server.use(cors());

server.use(express.json());//enable parsing of json data

//get all students
server.get("/students",function(request,response){
response.json(students);
});

//get  student by id
server.get("/students/:id",function(request,response){
     var studentId=parseInt(request.params.id);

     var student=students.filter((student,index)=>student.id==studentId)[0];
    response.json(student);

 });
    
//delete student by id
server.delete("/students/:id",function(request,response){
    var studentId=parseInt(request.params.id);

    students=students.filter((student,index)=>student.id!=studentId);
    response.json(students);

});
   

//update student by id
server.put("/students/:id",function(request,response){
    var studentId=parseInt(request.params.id);
    var data=request.body;


    students.forEach((student,index)=>{
         if(student.id==studentId)
         students[index]=data;
      });
    
    response.json(students);
});

//add student 
server.post("/students",function(request,response){
    var data=request.body;
    students.push(data);
   
    response.json(students);
});


server.listen(1111,function(){
console.log("Express Server listening on port 11111");
});
