import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn:'root'
})
export class StudentsService {

  private baseURL="http://localhost:1111/students";

    constructor(private http:HttpClient) {
           console.log("********* StudentsService created *******")
     }

     getAllStudents():Observable<any>{
      return this.http.get(this.baseURL);
    }

    getStudentById(studentId:number){
      return this.http.get(this.baseURL+"/"+studentId);
    }
    
    updateStudentById(studentId:number,student:any){
      return this.http.put(this.baseURL+"/"+studentId,student);
    }

   deleteStudentById(studentId:number){
      return this.http.delete(this.baseURL+"/"+studentId);
    }

    addStudent(student:any){
      return this.http.post(this.baseURL,student);
    }

    

}
